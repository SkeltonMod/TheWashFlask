
**QUICK LITTLE UPDATE** 




 As of now, I've been working on a game from a ludumdare game entry called "Warehouse Entry" and it's a fun game about throwing crates into delivery vans and paying taxes, so I came up with an idea of recreating this entry to an Isometric game where there are added mechanics.




 Right now, I'm working on the sprites although some of them aren't created faithfully (because I suck at art) but they do have some semblance




![Tilesets](https://filebin.net/spj1cs5czroy0eyy/Interior.png?t=zfjzm1ek)
  





 They look a bit rudimentary, but I'm working on polishing them.




 They don't really look convincing tbh.




  




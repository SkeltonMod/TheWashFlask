
 ayyyy just got a new upgrade for my PC, all these thanks to my ability to lie and make crappy software.




 whateves.




  












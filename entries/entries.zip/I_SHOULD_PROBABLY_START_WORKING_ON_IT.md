
 Being nearly finish with 4 projects at once, maybe I should start and build a working gameplay mechanic for my new game. just gonna allocate at least to 2 days for this though since I have to return to work after sunday.




 Duty calls!







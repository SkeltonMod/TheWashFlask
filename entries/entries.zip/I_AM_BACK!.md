
 It's ya boy washerman here, and finally after a few long months of inactivity, Social Parasite is finally back with a new look and feel! Hopefully this will last longer than the previous downtime, No promises this time though.




 What's new?






* 
 The Wash: New name for a new look of course
 

* 
 The (actual) Wash: This one is for short website ideas, currently it holds my anime list from MAL but it might change into another site gimmick in the future, hence the name "Wash"
 

* 
 Laundromat: Not yet implemented but this one is for longer site gimmicks, currently I'm working on a twitter like status updates that also grabs my tweets.
 

* 
 Garbage Bin: Also to be implemented but this one is where you can write your unpopular opinions on my site
 

* 
 Arcade: this one is coming right after I re-release my old games for HTML5, stay tuned for this one
 



 That's probably it for now, I'll be busy with finals and all that AMA bullshit so you better stay tuned for more updates.




 Cheers!



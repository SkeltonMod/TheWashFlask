
 Hey, just checking out this WYSISWYG editor that I made earlier




 and checking if it works or not either way here's an excerpt from the lyrics from my




 favorite 2pac music




 "Ain't nothin' but a gangsta party




 Ah shit, you done fucked up now (ain't nothin' but a gangsta party)




 You done put two of America's most wanted




 In the same motherfuckin' place at the same motherfuckin' time (ain't nothin' but a gangsta party)




 Y'all niggas about to feel this




 Break out the champagne glasses and the motherfuckin' condoms (ain't nothin' but a gangsta party)




 Have one on us aight (ain't nothin' but a gangsta party)"















































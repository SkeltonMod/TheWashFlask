
 Hey, it's been a while! I wasn't very active on this site lately because of that other thesis that I've been working on, but fret not imaginary reader, I'll start making posts tomorrow again.




 I'm probably just gonna paste the source code from elsewhere unto my JavaFX project, while it's bad to copy and paste code but I'm getting sick of making this clusterfuck of a project so I'm just gonna bite the bullet this time.




 whateves.












 Don't you just hate it when you just don't wanna do something creative or anything productive on a hot afternoon, that's what I'm currently in right now though my creative (if ever) energy would refill itself after a few hours of work or after a few days. It's really annoying to have your creative vibe ruined and you suddenly lack the motivation to do anything so you just listen to music or do whatever you feel like, that doesn't involve using the right or left hemisphere of you brain.




 Frustrations with this kind of work, probably also part of the fun maybe? I might try out nim later as a replacement for python since it's a compiled language which is a great addition and not only that; it has almost the same style and syntax as python.




 I'm 80% done with the JavaFX thesis and also relatively finished with the PHP project so that could explain my sudden exhaustion.




 Until my professor called and reminded me about the android project that's half way through being forgotten.




 whatever.



















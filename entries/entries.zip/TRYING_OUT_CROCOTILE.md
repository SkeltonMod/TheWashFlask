
 Lately, I convinced my mom to buy me Crocotile3D - A 3D modelling tool that uses tiles for modeling. I've got to say that right now I'm having a blast with this tool. I've been trying out the tileset that came with the tool when you first load a new project.




![](https://i.imgur.com/QXaAOlb.gif)
  





 I'm quite happy with Crocotile3D, It's better than sprytile on blender which is another 3D modelling tool that I have a hard time grasping on (I'm really just lazy all around).




 I'll be using this on my game project once I'm done with the thesis to which I didn't get to journal the new entry because the internet died. I sure do hope the final codebase would be a breeze to develop since I'm getting exhausted from doing non-creative programming work.




![](https://i.imgur.com/HZSOg1i.gif)
  









 Hmmm, I wonder if the code block works on this new WYSIWYG editor.




***<code>THIS IS A CODE</code>***




 if it doesn't then that's a big bummer.












 As you can tell by now, I'm still single not because I chose to but because I have no capabilities in engaging with someone romantically and that can stem from how I look down to how I see things. I don't blame the girls that I wanted to engage in romance though as It's partly my fault on why I am like this; well maybe a bit but you get my point. I did try romance before and it didn't work well, It had problems with my friends and my family. I can't just forget about them, they've been with me since all of this mess... wait, let me rephrase that. they've been with me even before all this "romance" thing even started so I can't just turn my back on them. After the catastrophe I had with bea, I then started to return to where I usually get rejected and that place is now known as "Omegle" HAHA! I remember that place, that's where I found my previous crushes and to name a few those girls are: Hart, Maria and Anna; and boy those girls gave me the hardest rejection ever. Fast forward a few weeks and I also returned to Facebook dating though I never experienced any rejection from that place... oh, wait I did and it was a close one, that came from this girl named Julianna; she's the type of girl that boys would normally fall for. Okay, let me be specific about this particular girl, she has this aura much like a femme fatale that's so vague it's gonna kill you or whatever life you cling on, So I had made my resolve and wanting to try and do some duck tape and wood glue courting until she started showing red flags of disinterest and that's where I realize, "hey maybe this thing isn't really for me" and then I went back to omegle and made a friend HAHA imagine if i'd gone the rejection route and this one would've been risky, since we live in the same city.




 I really owe a lot to Omegle as it helped me shape my own social understanding and how to deal with various kinds of people although it did put me in a cynical perspective towards other people, but still it is still worth noting how much I've learned from these "interesting" types of people. Fast forward a few more days and I've found all my old crushes in facebook from one particular friend that helped me (thanks!). Right now I'm still trying to muster up courage to confess to either one of my choice of crush but as we all know it would end in catastrophe. right now I'm still busy with doing the things I love and, those things being a disappointment to people and coding, the former seems to be more prevalent though. Maybe it's not really for me and I'm not made by some divine being to be with someone because of my self destructive attitude, well If anything, I'll never be that someone's supposed happiness; hell I can't even make my parents happy let alone other people... oh well, It's not like I'd die if I don't have a girlfriend or something but maybe I will , but from loneliness HAHAHAHA whatever though, bury me, I don't care, I'm already dead.















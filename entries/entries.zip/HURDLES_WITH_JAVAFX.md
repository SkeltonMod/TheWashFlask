
 Ughhh, just finished working on the employees part of the grad student's thesis and let me tell you it's not fun than it looks. It's been giving me headaches for at least 3 months now and why 3 months you ask and that is because the last 2 months, development was on pause and the client just got back to me asking if I can make this within to which my dumbass replied with a big YES! and I hastily made an MVC patterned system using glue and duck tape.




![](https://i.imgur.com/wZ4QVkV.png)
  





 I don't plan on re-organizing this though, once I'm done then I'm actually done with it and by that I mean deleting all traces of this abomination of a system.




 I also forgot there's another system along with this but that one is somewhat manageable since I have more experience with PHP than with Java especially with FXML; This is why I want late night chats so this chore of a work would be a bit manageable, I was hoping for that crush that I'd email to reach back to me but that's forlorn now and she's been inactive recently so I guess I won't bother her anymore but I digress, after this and that PHP system, I'm going straight into game development. I already convinced my mom to buy me Crocotile3D which is neat considering I wanna learn tile based modelling and tile based modelling only.




 Anyways, that's enough rambling for now. hope to see you here on my site soon reader.











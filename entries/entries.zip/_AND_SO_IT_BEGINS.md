
 Finally done with this janky and a bit awkward text editor using the quill js framework and I might have some
 
 complains here and there but it works nonetheless. I can now get back to working on the grad student's thesis, 
 which is the one below

 The indentations might be a bit odd when viewed though so be warned.

 That's all for now.

![](https://www.socialpara.site/entry_images/snippet.PNG)
  
























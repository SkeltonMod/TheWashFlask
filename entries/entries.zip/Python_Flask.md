
 I've been thinking of porting this whole site into python flask for easier scalability, I'm getting tired of doing all of the client side code by hand and felt the need to use templates instead. It might take a while this time since I'm really new to WSGI frameworks and such, plus the added rush from my academics and degrading motivation and ego. I'll be taking a break for a while , then just return to porting after weeks before finding a job (need to keep my resume in check).




 Quick little tangent in the realm of my pseudo creative life, I'll be trying a bunch of few things next week, and those will be,






* 
 Godot Sprite stacking - I'll be trying this out if the workload and stress of my not so creative jobs won't take a toll on me, I'll also be using this to simply try and rewrite either shootyman, badlands quest or nuclear thrones and see where my actual game dev skills would take me.
 

* 
 Defold Engine - Will probably just try and port badlands quest into this engine and see if lua works for me.
 

* 
 Blender Pixel Art Shader - Took me a few weeks to figure things out with this tool, might be of use if in tandem with my next endeavor.
 

* 
 PS1 styled 3D models - Bought a course from Miziziziz last week and I'm excited to try and learn blender again.
 



 And that's all for now, I'll keep this site updated after a few days.



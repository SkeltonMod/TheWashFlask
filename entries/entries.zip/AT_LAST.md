
 At long last i'm finally ditching JavaFX over PHP, which is my current strong point at the moment, and working with PHP is a breeze. What was supposed to be a 2 day implementation now reduced to hours or even minutes sometimes.




 Good times ahead!




 whateves.



















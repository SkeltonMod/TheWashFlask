
 As of now, I've been working on a simple isometric crate game to refresh my memory on game development and programming, among other things, I've also been learning how to edit models in blender for my next game given that I have enough motivation to start working on it, I'm also learning how to model in blender.




 I have recently bought GMS2 out of impulse hahaha I felt really stupid but now my tools have been expanded so it's either a win or a waste of money since I've had my success with Godot. I'm learning things beforehand so as to not waste my time fiddling around GameMaker when I'm working on a project which in turn would prevent me from losing motivation when working. I might make another game with Godot then move on to GameMaker to make at least 2 projects then just juggle around GMS2 or Godot from time to time to broaden my horizons.




 Planning on writing a novel for the second game but I feel like my writing (as with other creative aspects of my life) are as usual, lackluster. It will at least take me a bit of time to hone those said creative aspects of my life. Right now my ego and motivation is dwindling rapidly. I'm hoping to at least make a persona-like game before I graduate or just right before I die, hahahahaha!




 I will also be taking my second try in my driving exam, though I'm not really sure at all if I'll even passed this and even if I do, I suck at actual driving.




 That's probably all for now, The hosting provider is asking for my due this month and I might not be able to pay it in time, Oh well, no one's reading this blog anyway.




  




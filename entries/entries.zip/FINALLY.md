
 After a few weeks of intense coding and stack overflow surfing, I'm finally done with the grad student's thesis. Well at least for the second group but that's besides the point, My point is that I can finally sleep in the morning for a few more hours because of the additional time I now currently have HAHA! rejoice! so that means I have 6 hours of morning sleep and at least 4 hours JavaFX coding (the first group, which is a pain in the pass to work on) . The existential struggle I had with my convoluted PHP code is now finally over.




 I'm a few steps closer to my plan in resuming game development with Godot.




 Anyways, that's all for now. stay tune later for another midnight update.











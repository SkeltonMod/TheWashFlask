
 I'm writing this at 1 AM lmao... also, long intro inbound prepare yourselves for a giant wall of text




 Hey hey it's me nibble or as you might know me from Facebook as Magister and gvim80 from somewhere else. I'm a Computer Science student hailing from the glorious AMA Computer College of CDO I mostly write code with whatever language I can familiarize myself with but I don't consider myself as a professional, just intermediate since I have been jumping from one language to another. This site will be used to log all my activities during and probably after the quarantine.




 As you might have noticed, you got lost in the internet again, either you did a quickie scroll on twitter or you just clicked a bunch of sites, whatever it is welcome to my micro-blog; here you'll find a wide assortment of posts ranging from what I do most of the time, my adventures in coding (if you ever call it that), starting my career in game development (more on this below) and all the way to my frustrations with romance.




 Quick note




 I've been coding for almost 3 years now and it's mostly intermittent as I've been jumping from one language to another and today I've finally made the resolve to stick with one language and that is GDScript and Java (I lied about using one language) HAHA but for realsies I've been coding whatever project that comes up from either school or personal interest so I made this little micro-blog to journal my journey in this wacky world of softwares and IT albeit from a retard's perspective. I'll also be documenting what happens when I'm not doing my usual routine, i.e procrastinating and being a disappointment to everyone, do note that i'll only be documenting them here when they're actually worth sharing.




 I'll be updating this often or when my attention deficiency isn't acting up, the first few blogs might probably be about the systems I'm working for some Grad student's thesis and I might be also sharing a few key notes about this game that i've been prototyping on, though I haven't came up with a title yet. I hope you'd enjoy reading this little essay that I've wrote even if it has bad grammar and syntax. Links below would redirect you to my social media sites.




  












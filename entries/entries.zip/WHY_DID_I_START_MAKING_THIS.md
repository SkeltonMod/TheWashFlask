
 So, a while back I was stalking one of my crushes, her name is krishna by the way and I found something so hideous that it triggered my inner autism into motion and that is the weebly watermark at the corner. It sound a bit anticlimactic but it's also one of the few reason why this site exists and it's because I want to break away from my attention deficiency with updating things that I'm supposed to love doing, I quickly booted up my development environment and coded a very basic intro page and copy pasted a design over at codepen.io and so the side-quest begins (called it a sidequest because it's not connected to any of my current projects) but I do hope this reaches out to her and in fact I sent her an email a few days ago and got asked if I was a bot HAHA oh well, I guess my english grammar and structure sounds a bit monotone sometimes.




 Overall, I'm having fun using this little creation that I've made as it gave me a sense of accomplishment. even then the system for making the entries is kinda janky and a bit awkward, I'll sort them out once I'm done with all these systems that I've been paid to work on. Also, the data processing needs some work on this one as it's probably susceptible to haxxors and phreakers.




 I'll make sure to post something later though. The first few entries on this site will be about coding and probably a little bit about the women I admire during my lifetime. That sounded really creepy, I have a lot to talk about to my wonderful non-existent audience which makes you wonder why I'm so confident in telling you about this and that is partly because you as a reader might not exist at all and I'm just writing posts for non-existent people perhaps this message will serve as an indicator to me that you (the reader) actually exists and that you give a rat's ass about rants and ramblings here.




 All is well.














